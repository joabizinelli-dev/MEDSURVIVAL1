# MEDSURVIVAL

Manual de campo digital, gratuito e com prioridade para uso offline.

O código-fonte de referência está em [`MEDSURVIVAL/`](MEDSURVIVAL/). A documentação consolidada está em [`MEDSURVIVAL/docs/`](MEDSURVIVAL/docs/).

## Documentação
- [Visão geral](MEDSURVIVAL/docs/VISAO-GERAL.md)
- [Arquitetura técnica](MEDSURVIVAL/docs/ARQUITETURA-TECNICA.md)
- [Segurança e conteúdo](MEDSURVIVAL/docs/SEGURANCA-E-CONTEUDO.md)
- [Roadmap](MEDSURVIVAL/docs/ROADMAP.md)
- [Histórico e decisões](MEDSURVIVAL/docs/HISTORICO-E-DECISOES.md)

## Atenção antes de publicar
O pacote de referência 3.7 tem divergência de metadados: o Service Worker usa cache v37, mas `package.json` e partes de `LEIA-ME.txt` ainda indicam 3.6. Revisar e padronizar antes de publicar uma release.

Consulte `MEDSURVIVAL/LEIA-ME.txt` para instalação, recursos e limitações.
