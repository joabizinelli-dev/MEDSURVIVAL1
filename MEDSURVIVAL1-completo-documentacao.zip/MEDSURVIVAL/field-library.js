// Recursos de botânica, cultivo e acampamento: filtros locais, sem dependência de rede.
document.querySelectorAll('[data-plant-filter]').forEach(button=>button.addEventListener('click',()=>{
  const kind=button.dataset.plantFilter;
  document.querySelectorAll('[data-plant-filter]').forEach(b=>b.setAttribute('aria-pressed',String(b===button)));
  document.querySelectorAll('.plant-card').forEach(card=>{card.hidden=kind!=='all'&&card.dataset.kind!==kind});
}));
