/* MEDSURVIVAL 3.7 — Mapas: estradas, rios e municípios; mapas para baixar e usar sem internet. */
(()=>{
const RAD=Math.PI/180,sleep=ms=>new Promise(r=>setTimeout(r,ms)),esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const UF={AC:12,AL:27,AP:16,AM:13,BA:29,CE:23,DF:53,ES:32,GO:52,MA:21,MT:51,MS:50,MG:31,PA:15,PB:25,PR:41,PE:26,PI:22,RJ:33,RN:24,RS:43,RO:11,RR:14,SC:42,SP:35,SE:28,TO:17};
const mx=o=>(o+180)/360,my=a=>(1-Math.log(Math.tan(a*RAD)+1/Math.cos(a*RAD))/Math.PI)/2,ulo=x=>x*360-180,ula=y=>Math.atan(Math.sinh(Math.PI*(1-2*y)))/RAD;
/* classes: 1 rodovia · 2 principal · 3 secundária · 4 terciária · 5 rua · 6 serviço · 7 trilha de veículo · 8 caminho · 20 rio · 21 canal · 22 riacho */
const HW={motorway:1,trunk:1,primary:2,secondary:3,tertiary:4,unclassified:5,residential:5,living_street:5,service:6,track:7,path:8,bridleway:8},WW={river:20,canal:21,stream:22},hk=h=>HW[String(h).replace(/_link$/,'')];
const ESS='motorway|trunk|primary|secondary|tertiary|unclassified|track',FULL=ESS+'|residential|living_street|service|path|bridleway';
const tier=b=>(b[2]-b[0])*(b[3]-b[1])<=.3;
const qry=(b,full)=>{const a=`(${b[1].toFixed(5)},${b[0].toFixed(5)},${b[3].toFixed(5)},${b[2].toFixed(5)})`;return `[out:json][timeout:90];(way["highway"~"^(${full?FULL:ESS})(_link)?$"]${a};way["waterway"~"^(${full?'river|canal|stream':'river|canal'})$"]${a};node["place"~"^(city|town|village|hamlet)$"]${a};);out geom qt;`};
const cells=(b,st)=>{const o=[];for(let s=b[1];s<b[3];s+=st)for(let w=b[0];w<b[2];w+=st)o.push([w,s,Math.min(w+st,b[2]),Math.min(s+st,b[3])]);return o};
const newAcc=()=>({xy:[],off:[0],k:[],bb:[],nm:{},rf:{},pl:[],seen:new Set()});
const addEl=(a,e)=>{const id=e.type+e.id;if(a.seen.has(id))return;const t=e.tags||{};
if(e.type==='node'){if(t.place&&e.lon!=null){a.seen.add(id);a.pl.push([mx(e.lon),my(e.lat),t.place,t.name||''])}return}
if(e.type!=='way'||!e.geometry||e.geometry.length<2)return;const k=t.highway?hk(t.highway):WW[t.waterway];if(!k)return;a.seen.add(id);
let x0=9,y0=9,x1=-9,y1=-9;for(const g of e.geometry){const x=mx(g.lon),y=my(g.lat);a.xy.push(x,y);if(x<x0)x0=x;if(x>x1)x1=x;if(y<y0)y0=y;if(y>y1)y1=y}
a.off.push(a.xy.length/2);a.k.push(k);a.bb.push(x0,y0,x1,y1);const i=a.k.length-1;if(t.name)a.nm[i]=t.name;if(t.ref)a.rf[i]=String(t.ref).split(';')[0]};
const fin=a=>({xy:Float64Array.from(a.xy),off:Uint32Array.from(a.off),k:Uint8Array.from(a.k),bb:Float64Array.from(a.bb),nm:a.nm,rf:a.rf,pl:a.pl});
const rings=(g,o=[])=>{if(!g)return o;const c=g.coordinates;if(g.type==='Polygon')c.forEach(r=>o.push(r));else if(g.type==='MultiPolygon')c.forEach(p=>p.forEach(r=>o.push(r)));else if(g.type==='GeometryCollection')g.geometries.forEach(x=>rings(x,o));else if(g.geometry)rings(g.geometry,o);return o};
const flat=r=>{const f=new Float64Array(r.length*2);r.forEach((p,i)=>{f[2*i]=mx(p[0]);f[2*i+1]=my(p[1])});return f};
const bboxOf=rs=>{let w=181,s=91,e=-181,n=-91;rs.forEach(r=>r.forEach(p=>{if(p[0]<w)w=p[0];if(p[0]>e)e=p[0];if(p[1]<s)s=p[1];if(p[1]>n)n=p[1]}));return[w,s,e,n]};
const pip=(x,y,rs)=>{let c=false;for(const r of rs){const m=r.length/2;for(let i=0,j=m-1;i<m;j=i++){const xi=r[2*i],yi=r[2*i+1],xj=r[2*j],yj=r[2*j+1];if((yi>y)!==(yj>y)&&x<(xj-xi)*(y-yi)/(yj-yi)+xi)c=!c}}return c};
const rb=r=>{let a=9,b=9,c=-9,d=-9;for(let i=0;i<r.length;i+=2){if(r[i]<a)a=r[i];if(r[i]>c)c=r[i];if(r[i+1]<b)b=r[i+1];if(r[i+1]>d)d=r[i+1]}return[a,b,c,d]};
const prep=p=>{const q={...p,g:{},ln:[]};let x0=9,y0=9,x1=-9,y1=-9;const ext=(a,b,c,d)=>{x0=Math.min(x0,a);y0=Math.min(y0,b);x1=Math.max(x1,c);y1=Math.max(y1,d)};
if(p.k&&p.k.length){p.k.forEach((k,i)=>{(q.g[k]=q.g[k]||[]).push(i);if(p.nm[i]||p.rf[i])q.ln.push(i)});for(let i=0;i<p.bb.length;i+=4)ext(p.bb[i],p.bb[i+1],p.bb[i+2],p.bb[i+3])}
if(p.ol){q.olb=p.ol.map(rb);q.olb.forEach(b=>ext(...b))}
if(p.pg)q.pg=p.pg.map(g=>{const bs=g.r.map(rb),b=[Math.min(...bs.map(t=>t[0])),Math.min(...bs.map(t=>t[1])),Math.max(...bs.map(t=>t[2])),Math.max(...bs.map(t=>t[3]))];ext(...b);return{...g,b}});
q.nb=[x0,y0,x1,y1];return q};
const bytesOf=p=>(p.xy?p.xy.byteLength+p.off.byteLength+p.k.byteLength+p.bb.byteLength+JSON.stringify([p.nm,p.rf,p.pl]).length:0)+[...(p.ol||[]),...(p.pg||[]).flatMap(g=>g.r)].reduce((s,r)=>s+r.byteLength,0);

/* ---------- Desenho vetorial (estradas, rios, limites, nomes) ---------- */
const ORD=[20,21,22,6,5,8,7,4,3,2,1],COL={1:'#ff7a45',2:'#ffa94d',3:'#ffd166',4:'#f3e7b3',5:'#d2cab6',6:'#b9b19d',7:'#d49a45',8:'#ff9d6e',20:'#4aa8ff',21:'#4aa8ff',22:'#6bbcff'},WD={1:3.4,2:3,3:2.6,4:2.2,5:1.6,6:1.1,7:1.7,8:1.4,20:3.2,21:2.6,22:1.6},MZ={1:3,2:6,3:8,4:9,5:11,6:13,7:9,8:12,20:3,21:8,22:10},PZ={city:4,town:8,village:11,hamlet:12.5};
function render(c,w,h,cx,cy,z,PK,o){c.clearRect(0,0,w,h);if(!PK.length)return 0;
const s=256*2**z,X0=(cx-w/2)/s,X1=(cx+w/2)/s,Y0=(cy-h/2)/s,Y1=(cy+h/2)/s,ox=w/2-cx,oy=h/2-cy,f=z<8?.7:z<12?1:z<15?1.35:1.8,st=Math.max(1,Math.min(8,Math.round(2**(12-z)))),used=new Set(),vis=p=>!(p.nb[2]<X0||p.nb[0]>X1||p.nb[3]<Y0||p.nb[1]>Y1),out=(b)=>b[2]<X0||b[0]>X1||b[3]<Y0||b[1]>Y1;let nl=0,n=0;
const lab=(t,x,y,col,bold)=>{if(!o.n||nl>150||x<-40||y<-10||x>w+40||y>h+10)return;const a=Math.floor(x/18),b=Math.floor((x+t.length*6.2)/18),r=Math.floor(y/15);for(let i=a;i<=b;i++)if(used.has(i+','+r))return;for(let i=a;i<=b;i++)used.add(i+','+r);nl++;c.font=(bold?'700 ':'600 ')+'11px system-ui,sans-serif';c.lineWidth=3;c.strokeStyle='rgba(12,9,6,.88)';c.strokeText(t,x,y);c.fillStyle=col;c.fillText(t,x,y)};
const rp=r=>{const m=r.length/2,k=Math.max(1,Math.min(32,Math.round(2**(11-z))));c.moveTo(r[0]*s+ox,r[1]*s+oy);for(let v=k;v<m-1;v+=k)c.lineTo(r[2*v]*s+ox,r[2*v+1]*s+oy);c.lineTo(r[2*m-2]*s+ox,r[2*m-1]*s+oy)};
c.lineJoin='round';c.lineCap='round';c.textBaseline='middle';
if(o.m){c.beginPath();for(const p of PK){if(!vis(p))continue;if(p.ol)p.ol.forEach((r,i)=>{if(!out(p.olb[i]))rp(r)});if(p.pg)p.pg.forEach(g=>{if(!out(g.b))g.r.forEach(rp)})}c.setLineDash([7,5]);c.lineWidth=1.7;c.strokeStyle='rgba(244,234,208,.9)';c.stroke()}
for(const p of PK){if(!p.k||!vis(p))continue;for(const K of ORD){if(z<MZ[K]||(K>=20?!o.r:!o.e)||(o.lite&&(K===5||K===6)))continue;const ids=p.g[K];if(!ids)continue;
const path=()=>{c.beginPath();for(const i of ids){const j=4*i;if(p.bb[j+2]<X0||p.bb[j]>X1||p.bb[j+3]<Y0||p.bb[j+1]>Y1)continue;const a=p.off[i],e=p.off[i+1];c.moveTo(p.xy[2*a]*s+ox,p.xy[2*a+1]*s+oy);for(let v=a+st;v<e-1;v+=st)c.lineTo(p.xy[2*v]*s+ox,p.xy[2*v+1]*s+oy);c.lineTo(p.xy[2*e-2]*s+ox,p.xy[2*e-1]*s+oy);n++}};
if(K<=4&&!o.lite){path();c.setLineDash([]);c.lineWidth=(WD[K]+2)*f;c.strokeStyle='#1a140d';c.stroke()}
path();c.setLineDash(K===7?[6*f,4*f]:K===8?[2*f,3.5*f]:[]);c.lineWidth=WD[K]*f;c.strokeStyle=COL[K];c.stroke()}}
c.setLineDash([]);
for(const p of PK){if(!vis(p))continue;if(p.pl)for(const[x,y,k,t]of p.pl){if(z<(PZ[k]||99)||!t)continue;const px=x*s+ox,py=y*s+oy;if(px<0||py<0||px>w||py>h)continue;c.fillStyle='#f2e9d0';c.beginPath();c.arc(px,py,k==='city'?4:3,0,7);c.fill();lab(t,px+7,py,'#fff6dc',1)}
if(p.pg&&z>=7&&o.m)for(const g of p.pg){if(out(g.b))continue;lab(g.n,(g.b[0]+g.b[2])/2*s+ox-g.n.length*3,(g.b[1]+g.b[3])/2*s+oy,'#f2e9d0',1)}}
for(const p of PK){if(!p.k||!vis(p))continue;for(const i of p.ln){const K=p.k[i],r=K>=20;if(r?!o.r:!o.e)continue;if(r?z<10:K<=3?z<9:z<13)continue;const j=4*i;if(p.bb[j+2]<X0||p.bb[j]>X1||p.bb[j+3]<Y0||p.bb[j+1]>Y1)continue;
const v=(p.off[i]+p.off[i+1]-1)>>1,t=r?p.nm[i]:(K<=3&&z<13?p.rf[i]:p.nm[i]||p.rf[i]);if(t)lab(t,p.xy[2*v]*s+ox,p.xy[2*v+1]*s+oy,r?'#9fd2ff':'#ffe9a8')}}
return n}

if(typeof document==='undefined'){module.exports={mx,my,ulo,ula,addEl,newAcc,fin,rings,flat,bboxOf,pip,prep,cells,qry,tier,render,bytesOf,hk};return}

/* ---------- Armazenamento (IndexedDB) ---------- */
const DB=()=>new Promise((ok,no)=>{const r=indexedDB.open('ms-mapas',1);r.onupgradeneeded=()=>r.result.createObjectStore('p',{keyPath:'id'});r.onsuccess=()=>ok(r.result);r.onerror=()=>no(r.error)});
const tx=async(m,fn)=>{const d=await DB();return new Promise((ok,no)=>{const t=d.transaction('p',m),r=fn(t.objectStore('p'));t.oncomplete=()=>ok(r&&r.result);t.onerror=t.onabort=()=>no(t.error||new Error('Sem espaço no aparelho'))})};
const put=p=>tx('readwrite',s=>s.put(p)),del=id=>tx('readwrite',s=>s.delete(id)),all=()=>tx('readonly',s=>s.getAll());
let PK=[],loaded=false;const loadPacks=async()=>{if(loaded)return;loaded=true;try{PK=(await all()||[]).map(prep)}catch{PK=[]}};

/* ---------- Downloads (IBGE + OpenStreetMap/Overpass) ---------- */
const IB='https://servicodados.ibge.gov.br/api/',OV=['https://overpass-api.de/api/interpreter','https://overpass.kumi.systems/api/interpreter'];
const getJ=async(u,sig)=>{if(!navigator.onLine)throw new Error('Sem internet. Conecte-se para baixar.');const r=await fetch(u,{signal:sig});if(!r.ok)throw new Error('Servidor respondeu '+r.status);return r.json()};
const ovq=async(q,sig)=>{let er;for(let i=0;i<4;i++){try{const r=await fetch(OV[i%2],{method:'POST',signal:sig,headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'data='+encodeURIComponent(q)});if(r.ok){const j=await r.json();if(!(j.remark&&/error|timed out/i.test(j.remark)))return j;er=new Error('Servidor de mapas sobrecarregado')}else er=new Error('Servidor de mapas respondeu '+r.status)}catch(e){if(e.name==='AbortError')throw e;er=e}await sleep(3000*(i+1))}throw er};
const muni=async u=>{const k='ms.mu.'+u,s=localStorage.getItem(k);if(s)return JSON.parse(s);const l=(await getJ(IB+'v1/localidades/estados/'+u+'/municipios?orderBy=nome')).map(m=>[m.id,m.nome]);try{localStorage.setItem(k,JSON.stringify(l))}catch{}return l};
async function areaPack(b,prog,sig){const ar=(b[2]-b[0])*(b[3]-b[1]),cs=cells(b,ar>4?.5:.25),full=tier(b);if(cs.length>150)throw new Error('Área grande demais. Aproxime o mapa e baixe a área visível em partes.');const a=newAcc();
for(let i=0;i<cs.length;i++){prog(`Estradas e rios: parte ${i+1} de ${cs.length}…`);const j=await ovq(qry(cs[i],full),sig);j.elements.forEach(e=>addEl(a,e));if(i<cs.length-1)await sleep(1200)}
return{...fin(a),full}}
async function dlMuni(id,nome,u,prog,sig){prog('Limite do município…');const g=await getJ(IB+`v3/malhas/municipios/${id}?formato=application/vnd.geo+json&qualidade=intermediaria`,sig),rs=[];(g.type==='FeatureCollection'?g.features:[g]).forEach(x=>rings(x,rs));if(!rs.length)throw new Error('Limite do município não encontrado');
const p=await areaPack(bboxOf(rs),prog,sig);return{...p,id:'m'+id,kind:'m',nome:nome+' ('+u+')',ol:rs.map(flat)}}
async function dlArea(b,prog,sig){const p=await areaPack(b,prog,sig);return{...p,id:'a'+Date.now(),kind:'a',nome:`Área ${((b[1]+b[3])/2).toFixed(2)}, ${((b[0]+b[2])/2).toFixed(2)}`}}
async function dlLim(u,prog,sig){prog('Lista de municípios…');const nm=new Map(await muni(u));prog('Limites municipais…');const g=await getJ(IB+`v3/malhas/estados/${UF[u]}?formato=application/vnd.geo+json&intrarregiao=municipio&qualidade=minima`,sig),pg=[];
(g.features||[]).forEach(f=>{const r=rings(f.geometry).map(flat);if(r.length)pg.push({n:nm.get(+f.properties.codarea)||'',r})});if(!pg.length)throw new Error('Limites não encontrados');return{id:'l'+u,kind:'l',nome:'Municípios — '+u,pg}}

/* ---------- Tela da aba Mapas ---------- */
const Q=s=>document.querySelector(s),ov=document.createElement('div');ov.id='mapTab';ov.hidden=true;ov.dataset.l='r';
ov.innerHTML='<div id="mtView"><canvas id="mtVec"></canvas><div id="mtDot" hidden></div><div id="mtPin" hidden></div></div><div class="mt-top"><button id="mtBack" type="button" aria-label="Voltar">←</button><p id="mtInfo" class="mt-info">Toque no mapa para marcar um ponto</p><button id="mtDlB" type="button" aria-label="Mapas para baixar">⤓</button></div><div class="mt-ov" role="group" aria-label="O que mostrar"><button data-o="e" aria-pressed="true" type="button">Estradas</button><button data-o="r" aria-pressed="true" type="button">Rios</button><button data-o="m" aria-pressed="true" type="button">Municípios</button><button data-o="n" aria-pressed="true" type="button">Nomes</button></div><div class="mt-layers" role="group" aria-label="Fundo do mapa"><button data-l="r" aria-pressed="true" type="button">Ruas</button><button data-l="s" aria-pressed="false" type="button">Satélite</button><button data-l="o" aria-pressed="false" type="button">Offline</button></div><div class="mt-sheet" id="mtSheet" hidden><div><b></b><small></small></div><button id="mtCopy" type="button">Copiar</button><button id="mtClose" type="button" aria-label="Fechar">✕</button></div><div class="mt-scale" id="mtScale"></div><div class="mt-side"><button id="mtGps" type="button" aria-label="Minha posição">➤</button><div class="mt-zoom"><button id="mtIn" type="button" aria-label="Aproximar">+</button><button id="mtOut" type="button" aria-label="Afastar">−</button></div></div><p class="mt-foot">Ruas/Satélite exigem internet. © colaboradores do OpenStreetMap · IBGE · Esri. GPS só ao tocar em ➤.</p><div id="mtDl" hidden><div class="dl-box"><div class="dl-head"><b>Mapas para baixar</b><button id="dlX" type="button" aria-label="Fechar">✕</button></div><p class="dl-note" id="dlNote"></p><p class="dl-prog" id="dlProg" hidden></p><button id="dlCancel" class="dl-row-b" type="button" hidden>Cancelar download</button><button id="dlArea" class="dl-big" type="button">⤓ Baixar a área que estou vendo</button><div class="dl-sec">Baixados no aparelho</div><div id="dlMine"></div><div class="dl-sec">Brasil: escolha o estado</div><div class="ofi-chips" id="dlUf"></div><div id="dlList"></div></div></div>';
document.body.appendChild(ov);
const view=Q('#mtView'),cv=Q('#mtVec'),dot=Q('#mtDot'),pinEl=Q('#mtPin'),info=Q('#mtInfo'),sc=Q('#mtScale'),sheet=Q('#mtSheet');
const T=256,imgs=new Map(),P=new Map(),O={e:1,r:1,m:1,n:1},LY={r:['https://tile.openstreetmap.org/{z}/{x}/{y}.png'],s:['https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}','https://server.arcgisonline.com/ArcGIS/rest/services/Reference/World_Transportation/MapServer/tile/{z}/{y}/{x}'],o:[]};
let z=4,cx=0,cy=0,layer='r',me=null,pin=null,pd=0,sx=0,sy=0,t0=0,q=0,mv=0,mt=0,started=false;
const S=()=>T*2**z,ll=(la,lo)=>[mx(lo)*S(),my(la)*S()],setC=(la,lo,zz)=>{z=zz;[cx,cy]=ll(la,lo)},ctr=()=>[ula(cy/S()),ulo(cx/S())];
const saveV=()=>{try{const[a,o]=ctr();localStorage.setItem('ms.mv',JSON.stringify([+a.toFixed(5),+o.toFixed(5),z]))}catch{}};
function tiles(w,h){const n=2**z,keep=new Set();(LY[layer]||[]).forEach((u,li)=>{for(let x=Math.floor((cx-w/2)/T);x<=Math.floor((cx+w/2)/T);x++)for(let y=Math.max(0,Math.floor((cy-h/2)/T));y<=Math.min(n-1,Math.floor((cy+h/2)/T));y++){const k=li+'/'+z+'/'+x+'/'+y;keep.add(k);let im=imgs.get(k);if(!im){im=new Image();im.className='mt-t';im.alt='';im.draggable=false;im.decoding='async';im.src=u.replace('{z}',z).replace('{x}',((x%n)+n)%n).replace('{y}',y);imgs.set(k,im);view.appendChild(im)}im.style.transform=`translate(${Math.round(x*T-cx+w/2)}px,${Math.round(y*T-cy+h/2)}px)`}});imgs.forEach((im,k)=>{if(!keep.has(k)){im.remove();imgs.delete(k)}})}
function paint(){q=0;const w=view.clientWidth,h=view.clientHeight;if(!w)return;tiles(w,h);const d=Math.min(devicePixelRatio||1,2);if(cv.width!==Math.round(w*d)||cv.height!==Math.round(h*d)){cv.width=Math.round(w*d);cv.height=Math.round(h*d)}const c=cv.getContext('2d');c.setTransform(d,0,0,d,0,0);render(c,w,h,cx,cy,z,PK,mv?{...O,n:0,lite:1}:O);
for(const[el,m]of[[dot,me],[pinEl,pin]])if(m){const[a,b]=ll(m.la,m.lo);el.style.transform=`translate(${Math.round(a-cx+w/2)}px,${Math.round(b-cy+h/2)}px)`;el.hidden=false}
const[la,lo]=ctr(),mpp=40075016.686*Math.cos(la*RAD)/S(),raw=mpp*90,pw=10**Math.floor(Math.log10(raw)),fr=raw/pw,nice=(fr>=5?5:fr>=2?2:1)*pw;sc.style.width=Math.round(nice/mpp)+'px';sc.textContent=nice>=1000?nice/1000+' km':nice+' m';
info.textContent=layer==='o'&&!PK.length?'Nenhum mapa baixado. Toque em ⤓':`${la.toFixed(4)}, ${lo.toFixed(4)} · z${z}`}
const moving=()=>{mv=1;clearTimeout(mt);mt=setTimeout(()=>{mv=0;draw()},180)};
const draw=()=>{if(!q)q=requestAnimationFrame(paint)};
const zoom=d=>{const nz=Math.max(2,Math.min(18,z+d));if(nz===z)return;cx*=2**(nz-z);cy*=2**(nz-z);z=nz;saveV();moving();draw()};
const dist=()=>{const a=[...P.values()];return a.length<2?0:Math.hypot(a[0][0]-a[1][0],a[0][1]-a[1][1])};
const km=(a,b)=>{const t=x=>x*RAD;return 6371*Math.acos(Math.min(1,Math.sin(t(a.la))*Math.sin(t(b.la))+Math.cos(t(a.la))*Math.cos(t(b.la))*Math.cos(t(a.lo-b.lo))))};
const whereAt=(la,lo)=>{const x=mx(lo),y=my(la);for(const p of PK){if(x<p.nb[0]||x>p.nb[2]||y<p.nb[1]||y>p.nb[3])continue;if(p.pg){for(const g of p.pg)if(x>=g.b[0]&&x<=g.b[2]&&y>=g.b[1]&&y<=g.b[3]&&g.n&&pip(x,y,g.r))return g.n}else if(p.ol&&pip(x,y,p.ol))return p.nome.replace(/ \([A-Z]{2}\)$/,'')}return''};
function place(x,y){const r=view.getBoundingClientRect(),px=cx+x-r.left-r.width/2,py=cy+y-r.top-r.height/2;pin={la:ula(py/S()),lo:ulo(px/S())};const t=pin.la.toFixed(5)+', '+pin.lo.toFixed(5),d=me?km(me,pin):null,mu=whereAt(pin.la,pin.lo);sheet.dataset.c=t;sheet.querySelector('b').textContent=t;sheet.querySelector('small').textContent=(mu?'Município: '+mu+' · ':'')+(d==null?'toque em ➤ para ver a distância':(d<1?Math.round(d*1000)+' m':d.toFixed(1)+' km')+' de você');sheet.hidden=false;draw()}
view.onpointerdown=e=>{view.setPointerCapture(e.pointerId);P.set(e.pointerId,[e.clientX,e.clientY]);if(P.size===1){sx=e.clientX;sy=e.clientY;t0=Date.now()}pd=dist()};
view.onpointermove=e=>{const o=P.get(e.pointerId);if(!o)return;if(P.size===1){cx-=e.clientX-o[0];cy-=e.clientY-o[1];P.set(e.pointerId,[e.clientX,e.clientY]);moving();draw()}else{P.set(e.pointerId,[e.clientX,e.clientY]);const d=dist();if(pd&&d/pd>1.6){zoom(1);pd=d}else if(pd&&d/pd<.62){zoom(-1);pd=d}}};
view.onpointerup=view.onpointercancel=e=>{const tap=e.type==='pointerup'&&P.size===1&&Math.hypot(e.clientX-sx,e.clientY-sy)<6&&Date.now()-t0<450;P.delete(e.pointerId);pd=P.size===2?dist():0;saveV();if(tap)place(e.clientX,e.clientY)};
view.addEventListener('wheel',e=>{e.preventDefault();zoom(e.deltaY<0?1:-1)},{passive:false});view.ondblclick=()=>zoom(1);
Q('#mtIn').onclick=()=>zoom(1);Q('#mtOut').onclick=()=>zoom(-1);const close=()=>{ov.hidden=true};Q('#mtBack').onclick=()=>{const b=document.querySelector('.tabbar [data-tab=inicio]');if(b)b.click();else close()};
ov.querySelectorAll('[data-l]').forEach(b=>b.onclick=()=>{layer=b.dataset.l;ov.dataset.l=layer;ov.querySelectorAll('[data-l]').forEach(x=>x.setAttribute('aria-pressed',String(x===b)));draw()});
ov.querySelectorAll('[data-o]').forEach(b=>b.onclick=()=>{const k=b.dataset.o;O[k]=O[k]?0:1;b.setAttribute('aria-pressed',String(!!O[k]));draw()});
Q('#mtGps').onclick=()=>{if(!navigator.geolocation){info.textContent='GPS indisponível neste aparelho.';return}info.textContent='Buscando posição…';navigator.geolocation.getCurrentPosition(p=>{me={la:p.coords.latitude,lo:p.coords.longitude};setC(me.la,me.lo,Math.max(z,14));saveV();draw()},()=>{info.textContent='Não foi possível obter a posição (permissão negada ou sem sinal).'},{enableHighAccuracy:true,timeout:20000,maximumAge:60000})};
Q('#mtCopy').onclick=()=>{if(navigator.clipboard)navigator.clipboard.writeText(sheet.dataset.c).then(()=>{info.textContent='Coordenadas copiadas'}).catch(()=>{})};
Q('#mtClose').onclick=()=>{pin=null;pinEl.hidden=true;sheet.hidden=true};

/* ---------- Gerenciador de mapas para baixar ---------- */
const dl=Q('#mtDl'),note=Q('#dlNote'),progEl=Q('#dlProg'),canc=Q('#dlCancel'),mine=Q('#dlMine'),list=Q('#dlList'),ufB=Q('#dlUf');let ctl=null,curUF='';
const fmt=b=>b>=1e6?(b/1e6).toFixed(1)+' MB':Math.max(1,Math.round(b/1e3))+' KB';
const kindTxt=p=>p.kind==='p'?'fronteira do país':p.kind==='l'?'limites dos municípios':p.k?(p.full?'estradas, rios e nomes (completo)':'estradas principais, trilhas e rios'):'';
const prog=t=>{progEl.textContent=t||'';progEl.hidden=!t;canc.hidden=!t};
const storage=async()=>{try{const e=await navigator.storage.estimate();note.textContent=`Usando ${fmt(e.usage)} de ${fmt(e.quota)} disponíveis. Baixe com Wi-Fi: municípios grandes podem ter dezenas de MB e levar vários minutos.`}catch{note.textContent='Baixe com Wi-Fi. Municípios grandes podem ter dezenas de MB. Os mapas ficam guardados no aparelho.'}};
const fit=p=>{const[a,b,c,d]=p.nb,w=view.clientWidth||360,h=view.clientHeight||640,sp=Math.max((c-a)*256,(d-b)*256);let zz=Math.floor(Math.log2(Math.min(w,h)*.85/Math.max(sp,1e-9)));zz=Math.max(3,Math.min(15,zz));setC(ula((b+d)/2),ulo((a+c)/2),zz)};
async function go(fn,label){if(ctl)return;ctl=new AbortController();dl.classList.add('busy');try{try{await navigator.storage.persist()}catch{}const raw=await fn(prog,ctl.signal);raw.t=Date.now();raw.bytes=bytesOf(raw);await put(raw);PK=PK.filter(x=>x.id!==raw.id).concat(prep(raw));prog('');note.textContent=`Pronto: ${raw.nome} (${fmt(raw.bytes)}).`;if(raw.kind!=='l'||PK.length===1)fit(PK[PK.length-1]);saveV();draw()}
catch(e){prog('');note.textContent=e.name==='AbortError'?'Download cancelado.':e.name==='QuotaExceededError'?'Sem espaço no aparelho. Apague mapas antigos.':'Falhou: '+(e.message||'erro desconhecido')+'. Tente de novo.'}
finally{ctl=null;dl.classList.remove('busy');renderMine();renderList()}}
canc.onclick=()=>{if(ctl)ctl.abort()};
function renderMine(){mine.innerHTML=PK.length?'':'<p class="dl-note">Nenhum mapa baixado ainda.</p>';PK.forEach(p=>{const r=document.createElement('div');r.className='dl-row';r.innerHTML=`<span>${esc(p.nome)}<small>${kindTxt(p)} · ${fmt(p.bytes||bytesOf(p))} · ${new Date(p.t||Date.now()).toLocaleDateString('pt-BR')}</small></span><button type="button" data-a="v">Ver</button><button type="button" data-a="x">Apagar</button>`;r.querySelector('[data-a=v]').onclick=()=>{fit(p);dl.hidden=true;draw()};r.querySelector('[data-a=x]').onclick=async()=>{if(ctl||!confirm('Apagar "'+p.nome+'" do aparelho?'))return;await del(p.id);PK=PK.filter(x=>x.id!==p.id);renderMine();renderList();draw()};mine.appendChild(r)})}
async function renderList(){if(!curUF){list.innerHTML='';return}const u=curUF;let L;try{L=await muni(u)}catch(e){list.innerHTML='<p class="dl-note">Não foi possível carregar a lista de municípios: '+esc(e.message)+'. É preciso internet na primeira vez.</p>';return}if(u!==curUF)return;
const has=id=>PK.some(x=>x.id===id),row=(id,t,s,fn)=>{const r=document.createElement('div');r.className='dl-row';r.innerHTML=`<span>${esc(t)}<small>${s}</small></span><button type="button">${has(id)?'Atualizar':'Baixar'}</button>`;r.querySelector('button').onclick=fn;return r};
list.innerHTML='';list.appendChild(row('l'+u,'Limites de todos os municípios de '+u,'contornos e nomes · arquivo leve',()=>go((p,s)=>dlLim(u,p,s))));
const inp=document.createElement('input');inp.type='search';inp.placeholder='Buscar município de '+u;inp.id='dlQ';inp.autocomplete='off';list.appendChild(inp);const box=document.createElement('div');list.appendChild(box);
const norm=s=>s.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase(),show=()=>{const t=norm(inp.value),m=L.filter(([,n])=>norm(n).includes(t));box.innerHTML='';m.slice(0,60).forEach(([id,n])=>box.appendChild(row('m'+id,n,'estradas, rios e nomes do município',()=>go((p,s)=>dlMuni(id,n,u,p,s)))));if(m.length>60)box.insertAdjacentHTML('beforeend','<p class="dl-note">Mostrando 60 de '+m.length+'. Digite para filtrar.</p>')};inp.oninput=show;show()}
Object.keys(UF).forEach(u=>{const b=document.createElement('button');b.type='button';b.textContent=u;b.setAttribute('aria-pressed','false');b.onclick=()=>{curUF=u;[...ufB.children].forEach(x=>x.setAttribute('aria-pressed',String(x===b)));renderList()};ufB.appendChild(b)});
Q('#dlArea').onclick=()=>{if(ctl)return;const w=view.clientWidth,h=view.clientHeight,s=S(),b=[ulo((cx-w/2)/s),ula((cy+h/2)/s),ulo((cx+w/2)/s),ula((cy-h/2)/s)];if((b[2]-b[0])*(b[3]-b[1])>2){note.textContent='A área está grande demais. Aproxime o mapa (zoom 9 ou mais) e tente de novo.';return}go((p,sg)=>dlArea(b,p,sg))};
Q('#mtDlB').onclick=async()=>{dl.hidden=false;renderMine();storage()};Q('#dlX').onclick=()=>{dl.hidden=true};

/* ---------- Brasil inteiro e países ---------- */
async function allBR(){if(ctl)return;ctl=new AbortController();dl.classList.add('busy');const us=Object.keys(UF);let ok=0;
try{try{await navigator.storage.persist()}catch{}
for(let i=0;i<us.length;i++){prog(`Brasil: ${us[i]} (${i+1} de ${us.length})…`);const raw=await dlLim(us[i],()=>{},ctl.signal);raw.t=Date.now();raw.bytes=bytesOf(raw);await put(raw);PK=PK.filter(x=>x.id!==raw.id).concat(prep(raw));ok++;draw()}
note.textContent=`Pronto: limites de ${ok} estados.`}
catch(e){note.textContent=e.name==='AbortError'?`Cancelado (${ok} estados salvos).`:'Falhou: '+(e.message||'erro')+` (${ok} estados salvos). Tente de novo.`}
finally{prog('');ctl=null;dl.classList.remove('busy');renderMine();renderList()}}
const isoList=async()=>{const k='ms.paises',s=localStorage.getItem(k);if(s)return JSON.parse(s);const l=(await getJ(IB+'v1/paises')).map(p=>[p.id['ISO-3166-1-ALPHA-2'],p.nome.abreviado]).filter(x=>x[0]).sort((a,b)=>a[1].localeCompare(b[1],'pt'));try{localStorage.setItem(k,JSON.stringify(l))}catch{}return l};
async function dlPais(iso,nome,pr,sig){pr('Fronteira de '+nome+'…');const j=await ovq(`[out:json][timeout:90];relation["boundary"="administrative"]["admin_level"="2"]["ISO3166-1:alpha2"="${iso}"];out geom;`,sig),ol=[];
(j.elements||[]).forEach(e=>(e.members||[]).forEach(m=>{if(m.type==='way'&&m.geometry&&m.geometry.length>1)ol.push(flat(m.geometry.map(g=>[g.lon,g.lat])))}));
if(!ol.length)throw new Error('Fronteira não encontrada');return{id:'p'+iso,kind:'p',nome:nome+' (país)',ol}}
{const sec=[...dl.querySelectorAll('.dl-sec')].find(x=>/Brasil: escolha/.test(x.textContent)),bb=document.createElement('button');bb.type='button';bb.className='dl-big';bb.textContent='⤓ Brasil inteiro: limites de todos os estados e municípios';bb.onclick=allBR;sec.before(bb);
const ps=document.createElement('div');ps.className='dl-sec';ps.textContent='Países do mundo (fronteira)';const pi=document.createElement('input');pi.type='search';pi.placeholder='Buscar país';pi.autocomplete='off';const pl=document.createElement('div');dl.querySelector('.dl-box').append(ps,pi,pl);
const nz=s=>s.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();let PL=null;
const showP=async()=>{try{PL=PL||await isoList()}catch(e){pl.innerHTML='<p class="dl-note">Lista de países: '+esc(e.message)+' (precisa de internet na primeira vez).</p>';return}const t=nz(pi.value);pl.innerHTML='';PL.filter(([,n])=>nz(n).includes(t)).slice(0,40).forEach(([iso,n])=>{const r=document.createElement('div');r.className='dl-row';r.innerHTML=`<span>${esc(n)}<small>fronteira do país · ${esc(iso)}</small></span><button type="button">${PK.some(x=>x.id==='p'+iso)?'Atualizar':'Baixar'}</button>`;r.querySelector('button').onclick=()=>go((p,s)=>dlPais(iso,n,p,s));pl.appendChild(r)})};
pi.oninput=showP;pi.onfocus=()=>{if(!PL)showP()}}

/* ---------- Abrir a aba ---------- */
async function open(){ov.hidden=false;if(!started){started=true;let v=null;try{v=JSON.parse(localStorage.getItem('ms.mv'))}catch{}await loadPacks();if(v&&v.length===3)setC(v[0],v[1],v[2]);else if(PK.length)fit(PK[PK.length-1]);else setC(-14.2,-51.9,4)}draw()}
window.MS_MAPAS={open,close};if(location.hash==='#mapas')open();
})();
