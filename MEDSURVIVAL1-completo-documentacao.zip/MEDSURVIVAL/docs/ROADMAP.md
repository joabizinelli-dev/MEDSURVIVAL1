# Roadmap

Este documento consolida decisões e ideias; não significa que tudo já esteja implementado.

## Prioridades
### 1. Estabilidade
- Padronizar versão em todos os metadados.
- Preservar chaves de armazenamento e compatibilidade de backups.
- Testar cache e atualização do Service Worker.
- Manter tags/releases e branches de segurança.

### 2. Cartografia
- Melhorar seleção de região (mundo e Brasil).
- Ampliar mapas offline por região.
- Informar tamanho, fonte, data e limitações.
- Permitir gerenciar, exportar e remover mapas.

### 3. Manual de campo
- Organizar primeiros socorros, água, abrigo, fogo, higiene e navegação.
- Expandir conteúdo por bioma brasileiro.
- Melhorar busca e leitura em telas pequenas.

### 4. Botânica e autossuficiência
- Fichas educativas com identificação cautelosa.
- Separar espécies cultivadas, tóxicas e não identificadas.
- Guias de cultivo, conservação e acampamento com conteúdo original.

### 5. Compatibilidade
- PWA para iPhone, Android e computador.
- Testes reais em iOS e Android.
- Documentar recursos que variam por navegador/aparelho.

## Critérios mínimos de lançamento
- Metadados e cache coerentes.
- `npm run web:check` aprovado.
- Manifesto e configuração Capacitor válidos.
- Teste em modo avião.
- Teste de backup/restauração.
- Teste de mapas baixados offline.
- Revisão clínica e de segurança.
- Notas honestas sobre o que mudou e o que continua limitado.

## Estratégia
Trabalhar em incrementos pequenos. Criar branch/tag antes de mudanças críticas. Não substituir versão estável sem comparar diff e executar testes. Lançar diariamente somente quando houver mudança validada; não criar versões artificiais por calendário.
