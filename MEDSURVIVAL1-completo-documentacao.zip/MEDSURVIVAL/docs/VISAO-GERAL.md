# MEDSURVIVAL — visão geral

O MEDSURVIVAL é um manual de campo digital, gratuito, em português e com prioridade para funcionamento offline. Reúne material educativo de primeiros socorros, sobrevivência, orientação, cartografia, botânica responsável, cultivo, abrigo e autossuficiência.

## Princípios
1. **Offline primeiro:** guias e recursos essenciais devem continuar acessíveis sem conexão após instalação/cache e download dos dados necessários.
2. **Transparência:** indicar quando uma função exige internet, sensores, GPS ou dados baixados.
3. **Segurança:** conteúdo educativo não substitui treinamento, atendimento profissional ou protocolos oficiais.
4. **Privacidade:** localização somente quando solicitada pelo usuário; sem rastreamento contínuo ou envio automático de posição.
5. **Gratuito e independente:** manter o núcleo acessível sem assinatura.
6. **Multiplataforma:** PWA responsiva para celular e computador; avaliar empacotamento nativo com Capacitor.

## Módulos
- Início e pesquisa local.
- Medicina e primeiros socorros educativos.
- Plantas, biomas e cultivo com alertas contra identificação/consumo inseguro.
- Abrigo, água, higiene, fogo e sobrevivência.
- Navegação, GPS sob ação explícita do usuário, bússola quando suportada.
- Mapas vetoriais e dados geográficos baixáveis.
- Oficina e guias de autossuficiência.
- Diário, checklist e backup local.

## Plataformas
PWA em HTTPS para iOS, Android e navegadores desktop compatíveis. Capacitor é a rota para empacotamento nativo. Compilar iOS exige macOS/Xcode; Android exige Android Studio/SDK.

## O que não é
Não é serviço de emergência, não possui botão de emergência, não transmite localização automaticamente, não é navegador cartográfico profissional e não oferece IA generativa quando o recurso é apenas busca local.
