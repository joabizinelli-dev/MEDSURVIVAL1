# Histórico e decisões

## Direção do produto
Aplicativo gratuito, independente, em português e prioritariamente offline; interface de manual de campo; PWA multiplataforma; sem botão de emergência e sem envio automático da localização.

## Evolução consolidada
- **1.5:** base offline de primeiros socorros e sobrevivência.
- **2.1–2.3:** botânica, plantas cultivadas/tóxicas, cultivo, acampamento e autossuficiência.
- **2.4:** correções de interface/cartografia e melhorias de pesquisa.
- **2.5–2.8:** expansão de guias, dados e backup.
- **3.0:** direção Civilization Field Atlas.
- **3.3:** oficina e busca local (não IA generativa).
- **3.4:** guias de campo, biomas, Morse e economia de bateria.
- **3.5:** integridade SHA-256 dos novos backups.
- **3.6:** mapas como aba própria e downloads por município/área.
- **3.7:** pacote Mapas Extras, com motor de mapas separado e cache v37.

## Decisões a preservar
- Não inserir botão de emergência.
- Não transmitir localização automaticamente.
- Não chamar busca local de IA generativa.
- Não afirmar que mapas online/satélite funcionam offline.
- Não declarar testes em dispositivos reais sem executá-los.
- Não recomendar consumo de plantas silvestres por imagem.
- Produzir conteúdo original, sem copiar livros protegidos.

## Pendência de metadados
O ZIP 3.7 apresenta divergência: Service Worker usa cache v37, enquanto `package.json` e trechos do `LEIA-ME.txt` ainda indicam 3.6. Resolver antes de release.
