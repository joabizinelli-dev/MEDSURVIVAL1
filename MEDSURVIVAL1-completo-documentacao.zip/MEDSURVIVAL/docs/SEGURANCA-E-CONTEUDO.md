# Política de segurança e conteúdo

## Primeiros socorros
Conteúdo educativo não substitui avaliação profissional, protocolos locais ou treinamento prático. RCP, desengasgo, controle de hemorragias, anafilaxia e afogamento exigem capacitação. Antes de uso público, os guias médicos precisam de revisão clínica qualificada.

## Plantas, água e alimentos
- Não incentivar consumo de plantas, fungos ou frutos silvestres por semelhança visual.
- Ilustrações são educativas, não instrumentos de identificação.
- Não sugerir preparo de remédios com plantas desconhecidas.
- Não garantir potabilidade da água sem teste apropriado.

## Fogo e oficina
Priorizar prevenção e redução de risco. Não incluir instruções para fabricar armas, explosivos ou dispositivos perigosos.

## Navegação
Informar fonte, data e limitações dos dados. Não chamar mapa esquemático de carta topográfica nem prometer precisão de rota/altitude sem validação.

## Privacidade
A localização só deve ser solicitada quando o usuário acionar a função. Preservar a decisão de não incluir botão de emergência nem transmissão automática de localização.

## Revisão por versão
Revisar conteúdo médico, fontes/licenças, funcionamento offline, permissões, armazenamento e notas de versão antes de cada lançamento.
