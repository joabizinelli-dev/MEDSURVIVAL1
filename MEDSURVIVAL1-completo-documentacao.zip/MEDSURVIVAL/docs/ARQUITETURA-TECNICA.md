# Arquitetura técnica

## Estrutura do pacote de referência
- `index.html`: estrutura principal.
- `styles.css`: interface responsiva.
- `app.js`: lógica principal.
- `field-library.js`: biblioteca de conteúdo.
- `field-ui.js`: componentes e navegação.
- `field-atlas.js`: cartografia/atlas.
- `field-oficina.js`: oficina e autossuficiência.
- `field-campo.js`: conteúdo de campo.
- `field-mapas.js`: motor de mapas.
- `field-extra.js`: conteúdo complementar.
- `sw.js`: Service Worker/cache offline.
- `manifest.webmanifest`: metadados PWA.
- `capacitor.config.json` e `package.json`: integração Capacitor.
- `api/avisos.js`: endpoint auxiliar.
- `icons/`: ícones.

## Offline
O Service Worker armazena os arquivos essenciais. Dados geográficos adicionais precisam ser baixados com internet e ficam armazenados localmente conforme o módulo. GPS sem internet não significa que ruas, trilhas, relevo ou mapas já estejam disponíveis offline.

## Limites dos mapas
A versão de referência descreve camadas vetoriais e downloads por município/área, usando fontes como IBGE e OpenStreetMap/Overpass. Cobertura depende da região; downloads podem falhar; camadas de ruas/satélite online não ficam offline automaticamente. Não prometer rotas curva a curva, busca universal de endereços, curvas de nível ou navegação profissional.

## Armazenamento e privacidade
Diário, checklist, preferências e mapas são locais. Limpar dados do navegador, desinstalar ou trocar de aparelho pode apagar dados. O GPS deve ser acionado pelo usuário; não implementar rastreamento contínuo ou envio automático sem nova decisão explícita.

## Empacotamento
O pacote usa Capacitor 7 como caminho de integração nativa. O ZIP não contém projetos iOS/Android gerados, certificados, assinaturas nem builds de loja.

## Divergência a revisar
No pacote 3.7, o Service Worker usa cache v37, mas `package.json` e partes do `LEIA-ME.txt` ainda indicam 3.6. Padronizar versão, título e cache de forma coordenada antes de publicar.
